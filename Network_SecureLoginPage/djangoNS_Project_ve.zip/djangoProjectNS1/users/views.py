from django.contrib import messages
from django.shortcuts import render,redirect
from django.http import HttpResponse
from django.contrib.auth import authenticate
from django.template import loader
from .models import users,logging
from django.db import connection
import datetime

#For the hashing check
import bcrypt

# Create your views here.
def login(request):
    return render(request,"authentication/login.html")


#FOR loginResult function
def querryPasswordSearch(usernameInput):
    passwordQuerry = users.objects.raw('SELECT username,password \
        FROM users WHERE username = %s',[usernameInput])
            
    if len(passwordQuerry) == 0:
        return 0
    else:
        return passwordQuerry[0].password


# File to store login attempts
LOGIN_ATTEMPTS_FILE = 'users/login_attempts.txt' 

def loggingAttempts(username):
    #searchNumber of attempted loggins
    #after line = line.split(":")
    #line[0] = username
    #line[1] = logginAttempts
    #line[2] = lastTimePasswordChanged
     
    lineNumber = 0  
    with open(LOGIN_ATTEMPTS_FILE, 'r') as f:
        lines = f.readlines()
        for line in lines:
            line = line.split(":")
            if line[0] == username:
                #return loggin number attempts AND line number of account
                return line,lineNumber
            else:
                lineNumber+=1

#END HERE


def loginResult(request):
    if(request.method == "POST"):
        username = request.POST.get('username')
        password = request.POST.get('password')
  
        #Safe way to get the password , based on the username    
        passwordDB = querryPasswordSearch(username)
        
        #exitConditions => False WHEN:
        #1) passwordDB == 0
        #2) checkPassword == False
        
        #if this is true , it means the username is not in the database
        if(passwordDB == 0):
            messages.info(request,"Login Failed: Your username or password is incorrect")
            return redirect("login")
            
            
        #-----------------------------------#
        #-------SEARCH LOGGIN ATTEMPS-------#
        #-----------------------------------#
        
        # Number of allowed login attempts before account is locked
        MAX_ATTEMPTS = 3
    
        #userLineNumber => line of user in the login_attempts.txt file(for the writing part)
        userInfo,userLineNumber = loggingAttempts(username)
        
        #last password change , we have it as string here
        userLastPasswordChange = userInfo[2]
        
        #Convert strings to ints
        userLogginAttempts = int(userInfo[1])
        userLineNumber = int(userLineNumber)
        
        #Check if account is locked (here both passwords are correct)
        #Save on computations (dont hash etc)
        if(userLogginAttempts > MAX_ATTEMPTS):
            messages.error(request,"Login Failed: Account is locked")
            return redirect("login")
        
        #-----------------------------------#
        #-------SEARCH LOGGIN ATTEMPS-------#
        #--------------END------------------#
        
        
        #-----------------------------------#
        #---PASSWORD HASHING AND MATCHING---#
        #-----------------------------------#
        
        #Extracting Salt from password
        salt = passwordDB[:31]
        
        #Converting from string to byte
        #(remove the byte tag from string and encoding it)
        salt = salt[2:].encode()
        passwordDB = passwordDB[2:-1].encode()
        # encoding user password
        password = password.encode()
        
        # checking password
        result = bcrypt.checkpw(password, passwordDB)
        
        #-----------------------------------#
        #---PASSWORD HASHING AND MATCHING---#
        #--------------END------------------#
        
        
        #If this is False , and enters the if statement , it means
        #the user exists and the password given is incorrect
        if(result == False):
            
            ##--------------------------------------------##
            ##-----INCREMENT USER LOGGING NUMBER----------##
            ##--------------------------------------------##
            
            userLogginAttempts += 1
            
            #Get data (to change logging number)
            with open(LOGIN_ATTEMPTS_FILE, 'r') as f:
                data = f.readlines()

            #Change data to correct           
            data[userLineNumber] = f"{username}:{userLogginAttempts}:{userLastPasswordChange}"
            
            #Write data to txt file
            with open(LOGIN_ATTEMPTS_FILE, 'w') as f:
                f.writelines(data)
            
            ##---CHECK IF USER LOGGING NUMBER > MAX_ATTEMPTS---##
            if(userLogginAttempts > MAX_ATTEMPTS):
                messages.error(request,"Exceeded login retry limit. Account is now locked")
                return redirect("login") 
            ##--------------------END--------------------------##
            
            ##--------------------------------------------##
            ##-----INCREMENT USER LOGGING NUMBER----------##
            ##-----------------END------------------------##
            
            messages.info(request,"Login Failed: Your username or password is incorrect")
            return redirect("login")
         
        
        ##--------------------------------------------##
        ##-----CHANGE PASSWORD NOTIFICATION-----------##
        ##--------------------------------------------##
        
        #Days since the last change of the password
        PASSWORD_EXPIRATION_INTERVAL = 90
        
        #Convert date string to date (of userLastPasswordChange variable)
        #userLastPasswordChange[:-2] => the -2 to remove the string /n
        userLastPasswordChange = datetime.datetime.strptime(userLastPasswordChange[:-2], '%Y-%m-%d').date()
        
        passwordExpirationTime = userLastPasswordChange + datetime.timedelta(days=PASSWORD_EXPIRATION_INTERVAL)
        
        changePasswordMessage = ""
        if datetime.datetime.now().date() > passwordExpirationTime:
            changePasswordMessage = f"Change of password is recommended!"
            
        ##--------------------------------------------##
        ##--------CHANGE PASSWORD NOTIFICATION--------##
        ##-----------------END------------------------##
        
        
        ##--------------------------------------------##
        ##------------LOG SUCCESFUL PASSWORD----------##
        ##--------------------------------------------##
        
        logging(username=username,successfulLogin=datetime.datetime.now()).save()  
        
        ##--------------------------------------------##
        ##------------LOG SUCCESFUL PASSWORD----------##
        ##------------------END-----------------------##
        
        
        messages.success(request,f"Loged in as: {username}")
        messages.success(request,f"{changePasswordMessage}")
        return render(request,"authentication/loginResult.html")
    
    return render(request,"authentication/loginResult.html")
        