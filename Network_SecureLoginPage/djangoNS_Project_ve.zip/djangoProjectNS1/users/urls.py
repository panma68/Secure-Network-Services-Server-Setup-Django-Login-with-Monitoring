from django.contrib import admin
from django.urls import path,include
from django.contrib.messages.views import SuccessMessageMixin
from . import views

urlpatterns = [
    path('',views.login, name="login"),   
    path('loginResult',views.loginResult, name="loginResult")
]