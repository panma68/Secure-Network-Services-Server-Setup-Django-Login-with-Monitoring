from django.db import models

#For hashing the password
import bcrypt


# My logging table
class logging(models.Model):
    username = models.CharField(models.ForeignKey("users", on_delete = models.CASCADE) , max_length=255)
    successfulLogin = models.DateTimeField()
    
    class Meta:
        db_table = "logging"
        
        
# My users table
class users(models.Model):
        
    username = models.CharField(max_length=255 , primary_key=True)
    password = models.CharField(max_length=255)
    description = models.TextField()
    
    class Meta:
        db_table = "users"
    
    def save(self, *args, **kwargs):
        #Here we hash the password before saving it to the database
        self.password = bcrypt.hashpw(self.password.encode(),bcrypt.gensalt()) 
        super().save(*args, **kwargs)
    